class DbInfo:
    def __init__(self,size="",rol="",direction=""):
        self.size = size
        self.rol = rol
        self.direction = direction